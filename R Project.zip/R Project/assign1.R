 library(RMySQL)
mydb = dbConnect(MySQL(), user='root', password='', host='localhost')
dbGetInfo(mydb)
dbSendQuery(mydb, "CREATE DATABASE RAssignment;")
dbSendQuery(mydb, "USE RAssignment;")
dbSendQuery(mydb, "CREATE TABLE invoices(invoiceId INT AUTO_INCREMENT PRIMARY KEY, invoiceNo INT, FSNumber INT, subtotal DOUBLE, paymentMethod VARCHAR(50), grandTotal DOUBLE, status VARCHAR(50));") #create table invoices
dbSendQuery(mydb, "CREATE TABLE sellers(sellerId INT AUTO_INCREMENT PRIMARY KEY, sellerName VARCHAR(50), VatNumber INT, TinNumber INT, Woreda INT, houseNumber INT, phoneNumber INT, subcity VARCHAR(50), POBox INT);") #create table sellers
dbSendQuery(mydb, "CREATE TABLE buyers(buyerId INT AUTO_INCREMENT PRIMARY KEY, buyerName VARCHAR(50), buyerTinNumber INT, buyerVatNumber INT);")#create table buyers
dbSendQuery(mydb, "CREATE TABLE items(itemId INT AUTO_INCREMENT PRIMARY KEY,  description VARCHAR(50), unitPrice INT, totalPrice INT, quantity INT);")#create table items
dbListTables(mydb)

dbSendQuery(mydb, "ALTER TABLE items CHANGE COLUMN totalPrice itemName VARCHAR(50);")
dbSendQuery(mydb, "ALTER TABLE invoices ADD COLUMN seller_Id INT NOT NULL, ADD CONSTRAINT FK_sellers_sellerId FOREIGN KEY (seller_Id) REFERENCES sellers(sellerId);") # add seller id as foreign key 
dbSendQuery(mydb, "ALTER TABLE invoices ADD COLUMN buyer_Id INT NOT NULL, ADD CONSTRAINT FK_buyers_buyerId FOREIGN KEY (buyer_Id) REFERENCES buyers(buyerId);") # add buyer id as foreign key 
dbSendQuery(mydb, "ALTER TABLE invoices ADD COLUMN item_Id INT NOT NULL, ADD CONSTRAINT FK_items_itemId FOREIGN KEY (item_Id) REFERENCES items(itemId);") # add item id as foreign key 

#insert values
dbSendQuery(mydb, "INSERT INTO sellers (sellerName, VatNumber, TinNumber, Woreda, houseNumber, phoneNumber, subcity, POBox) VALUES ('MT PLC', 36543742, 000045794, 2, 325, 0, 'Yeka', 43567);")
dbSendQuery(mydb, "INSERT INTO buyers (buyerName, buyerTinNumber, buyerVatNumber) VALUES ('XYZ inc', 000576678, 76780432);")
dbSendQuery(mydb, "INSERT INTO buyers (buyerName, buyerTinNumber, buyerVatNumber) VALUES ('Kebede Construction', 000443421, 67932453);")
dbSendQuery(mydb, "INSERT INTO buyers (buyerName, buyerTinNumber, buyerVatNumber) VALUES ('AM inc', 000321134, 94732142);")
dbSendQuery(mydb, "INSERT INTO items (description, unitPrice, itemName, quantity) VALUES ('Dell core i5', 14000, 'Laptop', 10);") 
dbSendQuery(mydb, "INSERT INTO items (description, unitPrice, itemName, quantity) VALUES ('Lenovo Z41', 17000, 'Laptop', 4);") 
dbSendQuery(mydb, "INSERT INTO items (description, unitPrice, itemName, quantity) VALUES ('HP', 20000, 'Printer', 6);")
dbSendQuery(mydb, "INSERT INTO invoices (invoiceNo, FSNumber, subtotal, paymentMethod, grandTotal, status, seller_Id, buyer_Id, item_Id ) VALUES (1, 001, 14000, 'cash', 21000, 'active', 1, 1, 1);") 
dbSendQuery(mydb, "INSERT INTO invoices (invoiceNo, FSNumber, subtotal, paymentMethod, grandTotal, status, seller_Id, buyer_Id, item_Id ) VALUES (2, 002, 10000, 'cheque', 31000, 'active', 1, 2, 2);") 
dbSendQuery(mydb, "INSERT INTO invoices (invoiceNo, FSNumber, subtotal, paymentMethod, grandTotal, status, seller_Id, buyer_Id, item_Id ) VALUES (3, 003, 13000, 'cash', 16000, 'active', 1, 3, 3);") 

#read statement
read = fetch(dbSendQuery(mydb, "SELECT invoices.invoiceId, invoiceNo, FSNumber, subtotal, paymentMethod, grandTotal, status, sellerName, VatNumber, TinNumber, Woreda, houseNumber, phoneNumber, subcity, POBox, buyerName, buyerTinNumber, buyerVatNumber, description, unitPrice, itemName, quantity FROM invoices, sellers, buyers, items WHERE sellers.sellerId=1 & buyers.buyerId=1 & items.itemId=1 & invoices.invoiceId=1;")) 
read

#update statement
dbSendQuery(mydb, "UPDATE items SET quantity = quantity-1 WHERE itemId=1 ;")

#Delete statement
dbSendQuery(mydb, "DELETE FROM invoices WHERE invoiceId=3 ;")

newframe = fetch(dbSendQuery(mydb, "SELECT * FROM invoices;"))

newframe$vat<- newframe$grandTotal - newframe$subtotal
newframe

dbWriteTable(mydb, "invoices", newframe, overwrite= TRUE)

dbReadTable(mydb, "invoices")
 #summary of dataframe
head(newframe) 

tail(newframe)

summary(newframe)
